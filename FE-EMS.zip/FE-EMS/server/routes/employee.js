// Add this new route to your existing employee routes file

const express = require('express');
const router = express.Router();
const Employee = require('../models/Employee');
const User = require('../models/User');
const auth = require('../middleware/auth');

// Create employee profile
router.post('/create', auth, async (req, res) => {
  try {
    const {
      personal_details,
      address,
      education,
      skills
    } = req.body;

    // Generate registration number
    const count = await Employee.countDocuments();
    const registration_number = `EMP${String(count + 1).padStart(4, '0')}`;

    // Create employee
    const employee = await Employee.create({
      userId: req.user._id,
      registration_number,
      personal_details: {
        ...personal_details,
        email: req.user.email,
        name: req.user.name
      },
      address,
      education,
      skills
    });

    // Update user registration status
    await User.findByIdAndUpdate(req.user._id, {
      registrationStatus: 'completed'
    });

    res.status(201).json({
      success: true,
      message: 'Employee profile created successfully',
      employee
    });

  } catch (error) {
    console.error('Employee creation error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// Search by registration number
router.post('/search', auth, async (req, res) => {
  try {
    const { registration_number } = req.body;

    const employee = await Employee.findOne({ registration_number });

    if (!employee) {
      return res.status(404).json({
        success: false,
        message: 'Employee not found'
      });
    }

    res.status(200).json({
      success: true,
      employee
    });

  } catch (error) {
    console.error('Search error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// Search by skills
router.post('/search-by-skills', auth, async (req, res) => {
  try {
    const { skills } = req.body;

    if (!skills) {
      return res.status(400).json({
        success: false,
        message: 'Please provide skills to search'
      });
    }

    const employees = await Employee.find({
      $text: { $search: skills }
    }).sort({
      score: { $meta: 'textScore' }
    });

    if (employees.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No employees found with the specified skills'
      });
    }

    res.status(200).json({
      success: true,
      count: employees.length,
      employees
    });

  } catch (error) {
    console.error('Skills search error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

module.exports = router; 