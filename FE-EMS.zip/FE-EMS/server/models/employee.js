const mongoose = require('mongoose');

const employeeSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  registration_number: {
    type: String,
    required: true,
    unique: true
  },
  personal_details: {
    name: {
      type: String,
      required: true
    },
    dob: Date,
    gender: {
      type: String,
      enum: ['male', 'female', 'other']
    },
    mobile: {
      type: String,
      required: true,
      unique: true
    },
    alternate_mobile: String,
    email: {
      type: String,
      required: true
    }
  },
  address: {
    street: String,
    city: String,
    state: String,
    pincode: String,
    country: String
  },
  education: [{
    degree: String,
    institution: String,
    year: Number,
    percentage: Number
  }],
  skills: {
    type: String,
    required: true
  },
  created_at: {
    type: Date,
    default: Date.now
  },
  updated_at: {
    type: Date,
    default: Date.now
  }
});

// Update timestamp on save
employeeSchema.pre('save', function(next) {
  this.updated_at = Date.now();
  next();
});

// Create index for skills search
employeeSchema.index({ skills: 'text' });

module.exports = mongoose.model('Employee', employeeSchema); 