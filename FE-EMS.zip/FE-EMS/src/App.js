import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Login from './pages/Login';
import UserRegistration from './pages/UserRegistration';
import Registration from './Registration';
import SearchPage1 from './SearchPage1';
import FAQ from './pages/FAQ';
import Helpline from './pages/Helpline';
import './App.css';

// Protected Route component
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return <div>Loading...</div>;
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }

  return children;
};

function App() {
  const { isAuthenticated, logout } = useAuth();

  const handleLogout = () => {
    logout();
    window.location.href = '/login';
  };

  return (
    <div className="app-container">
      <nav className="nav-menu">
        <ul>
          {isAuthenticated && (
            <>
              <li><Link to="/registration">Registration</Link></li>
              <li><Link to="/search">Search</Link></li>
              <li>
                <button 
                  onClick={handleLogout}
                  className="logout-button"
                >
                  Logout
                </button>
              </li>
              <li><Link to="/faq">FAQ</Link></li>
              <li><Link to="/helpline">Helpline</Link></li>
            </>
          )}
        </ul>
      </nav>

      <div className="content-container">
        <Routes>
          <Route 
            path="/login" 
            element={isAuthenticated ? <Navigate to="/registration" /> : <Login />} 
          />
          <Route 
            path="/register" 
            element={isAuthenticated ? <Navigate to="/registration" /> : <UserRegistration />} 
          />
          <Route 
            path="/registration" 
            element={isAuthenticated ? <Registration /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/search" 
            element={isAuthenticated ? <SearchPage1 /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/faq" 
            element={isAuthenticated ? <FAQ /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/helpline" 
            element={isAuthenticated ? <Helpline /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/" 
            element={<Navigate to={isAuthenticated ? "/registration" : "/login"} />} 
          />
        </Routes>
      </div>
    </div>
  );
}

// Wrap the App with AuthProvider
const AppWithAuth = () => {
  return (
    <AuthProvider>
      <Router>
        <App />
      </Router>
    </AuthProvider>
  );
};

export default AppWithAuth;
 
 