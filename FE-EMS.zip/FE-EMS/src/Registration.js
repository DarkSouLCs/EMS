import React, { useState, useEffect } from "react";
import "./Registration.css";
import Select from 'react-select';
import { useNavigate } from 'react-router-dom';
import { employeeAPI } from './services/api';

const skillOptions = [
  { value: "JavaScript", label: "JavaScript" },
  { value: "Python", label: "Python" },
  { value: "Java", label: "Java" },
  { value: "C++", label: "C++" },
  { value: "React", label: "React" },
  { value: "Node.js", label: "Node.js" },
  { value: "HTML/CSS", label: "HTML/CSS" },
  { value: "SQL", label: "SQL" },
  { value: "MongoDB", label: "MongoDB" },
  { value: "AWS", label: "AWS" },
  { value: "Docker", label: "Docker" },
  { value: "Git", label: "Git" },
  { value: "Angular", label: "Angular" },
  { value: "Vue.js", label: "Vue.js" },
  { value: "PHP", label: "PHP" },
  { value: "Ruby", label: "Ruby" },
  { value: "Machine Learning", label: "Machine Learning" },
  { value: "Data Analysis", label: "Data Analysis" },
  { value: "Cybersecurity", label: "Cybersecurity" },
  { value: "DevOps", label: "DevOps" }
];

const Registration = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    first_name: "",
    middle_name: "",
    last_name: "",
    mobile_number: "",
    address_1: "",
    address_2: "",
    dob: "",
    city: "",
    state: "",
    pincode: "",
    experience: "",
    education: "",
    otherEducation: "",
    selectedSkills: [],
    hasOtherSkills: false,
    otherSkills: "",
    skills: [],
    email: "",
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState({ type: '', message: '' });
  const navigate = useNavigate();
  const [showFAQ, setShowFAQ] = useState(false);
  const [showHelpline, setShowHelpline] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login');
    }
  }, [navigate]);

  // Load saved form data when email is entered
  useEffect(() => {
    const loadSavedData = async () => {
      if (formData.email && formData.email.match(emailRegex)) {
        try {
          const savedData = await employeeAPI.getRegistrationData(formData.email);
          if (savedData) {
            setFormData(prevData => ({
              ...prevData,
              ...savedData
            }));
          }
        } catch (error) {
          console.error('Error loading saved data:', error);
        }
      }
    };

    loadSavedData();
  }, [formData.email]);

  // Validation Regex
  const nameRegex = /^[a-zA-Z\s]{2,50}$/;
  const middleRegex = /^[a-zA-Z\s]{0,50}$/;
  const lastNameRegex = /^[a-zA-Z\s]{2,50}$/;
  const mobile_numberRegex = /^[0-9]{10}$/;
  const cityRegex = /^[a-zA-Z\s]{2,50}$/;
  const stateRegex = /^[a-zA-Z\s]{2,50}$/;
  const pincodeRegex = /^[0-9]{6}$/;
  const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
  const addressRegex = /^[a-zA-Z0-9\s,.-]{5,100}$/;

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    // Auto-capitalize name fields
    if (['first_name', 'middle_name', 'last_name'].includes(name)) {
      const capitalizedName = value
        .toLowerCase()
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
      setFormData({ ...formData, [name]: capitalizedName });
    } 
    // Auto-capitalize city and state fields
    else if (['city', 'state'].includes(name)) {
      const capitalizedValue = value
        .toLowerCase()
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
      setFormData({ ...formData, [name]: capitalizedValue });
    }
    else {
      setFormData({ ...formData, [name]: value });
    }
    setErrors({});
  };

  const validateForm = () => {
    let newErrors = {};

    if (step === 1) {
      if (!formData.first_name.trim()) {
        newErrors.first_name = "First name is required";
      } else if (!formData.first_name.match(nameRegex)) {
        newErrors.first_name = "First name should be 2-50 characters and contain only letters";
      }

      if (formData.middle_name && !formData.middle_name.match(middleRegex)) {
        newErrors.middle_name = "Middle name should contain only letters";
      }

      if (!formData.last_name.trim()) {
        newErrors.last_name = "Last name is required";
      } else if (!formData.last_name.match(lastNameRegex)) {
        newErrors.last_name = "Last name should be 2-50 characters and contain only letters";
      }

      if (!formData.mobile_number.trim()) {
        newErrors.mobile_number = "Mobile number is required";
      } else if (!formData.mobile_number.match(mobile_numberRegex)) {
        newErrors.mobile_number = "Please enter a valid 10-digit mobile number";
      }

      if (!formData.email.trim()) {
        newErrors.email = "Email is required";
      } else if (!formData.email.match(emailRegex)) {
        newErrors.email = "Please enter a valid email address";
      }
    }

    if (step === 2) {
      if (!formData.address_1.trim()) {
        newErrors.address_1 = "Address Line 1 is required";
      } else if (!formData.address_1.match(addressRegex)) {
        newErrors.address_1 = "Please enter a valid address (5-100 characters)";
      }

      if (formData.address_2 && !formData.address_2.match(addressRegex)) {
        newErrors.address_2 = "Please enter a valid address (5-100 characters)";
      }

      if (!formData.city.trim()) {
        newErrors.city = "City is required";
      } else if (!formData.city.match(cityRegex)) {
        newErrors.city = "Please enter a valid city name";
      }

      if (!formData.state.trim()) {
        newErrors.state = "State is required";
      } else if (!formData.state.match(stateRegex)) {
        newErrors.state = "Please enter a valid state name";
      }

      if (!formData.pincode.trim()) {
        newErrors.pincode = "Pincode is required";
      } else if (!formData.pincode.match(pincodeRegex)) {
        newErrors.pincode = "Please enter a valid 6-digit pincode";
      }
    }

    if (step === 3) {
      if (!formData.education) {
        newErrors.education = "Please select your education level";
      } else if (formData.education === "Others" && !formData.otherEducation.trim()) {
        newErrors.otherEducation = "Please specify your education";
      }
      
      if (!formData.experience) {
        newErrors.experience = "Please select your experience level";
      }
      
      if (formData.skills.length === 0) {
        newErrors.skills = "Please select at least one skill";
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep3 = () => {
    return (
      formData.education &&
      (formData.education !== "Others" || formData.otherEducation.trim()) &&
      formData.experience &&
      formData.skills.length > 0 && // Check if at least one skill is selected
      formData.email.match(emailRegex)
    );
  };

  const nextStep = () => {
    if (validateForm()) {
      setStep(step + 1);
    }
  };

  const prevStep = () => setStep(step - 1);

  const handleSubmit = async () => {
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    setSubmitStatus({ type: '', message: '' });

    try {
      // Prepare the data for submission
      let updatedFormData = { ...formData };
      
      // Handle education field
      if (updatedFormData.education === "Others") {
        updatedFormData.education = updatedFormData.otherEducation;
      }
      delete updatedFormData.otherEducation;
      
      // Handle skills
      if (updatedFormData.selectedSkills && updatedFormData.selectedSkills.length > 0) {
        updatedFormData.skills = updatedFormData.selectedSkills.map(skill => skill.value);
      } else if (updatedFormData.hasOtherSkills && updatedFormData.otherSkills) {
        updatedFormData.skills = [updatedFormData.otherSkills];
      } else {
        updatedFormData.skills = [];
      }
      
      // Create employee record
      const response = await employeeAPI.createEmployee(updatedFormData);
      
      // Display success message with registration number
      setSubmitStatus({
        type: 'success',
        message: `Registration successful! Your registration number is: ${response.registration_number || response.registrationNumber}`
      });
      
      // Clear form after successful submission
      setFormData({
        first_name: "",
        middle_name: "",
        last_name: "",
        mobile_number: "",
        address_1: "",
        address_2: "",
        city: "",
        state: "",
        pincode: "",
        experience: "",
        education: "",
        otherEducation: "",
        selectedSkills: [],
        hasOtherSkills: false,
        otherSkills: "",
        skills: [],
        email: "",
      });
      
      // Reset to first step
      setStep(1);
      
      // Redirect to search page after 3 seconds
      setTimeout(() => {
        navigate('/search');
      }, 3000);
      
    } catch (error) {
      console.error('Registration error:', error);
      setSubmitStatus({
        type: 'error',
        message: error.message || 'Registration failed. Please try again.'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStep1 = () => (
    <div className="form-step">
      <h3>Personal Details</h3>
      <div className="name-fields-grid">
        <div className="form-group">
          <label data-required>First Name</label>
          <input
            type="text"
            name="first_name"
            value={formData.first_name}
            onChange={handleChange}
            placeholder="Enter first name"
            className="capitalize-input"
            required
          />
        </div>
        
        <div className="form-group optional-field">
          <label>Middle Name (Optional)</label>
          <input
            type="text"
            name="middle_name"
            value={formData.middle_name}
            onChange={handleChange}
            placeholder="Enter middle name"
            className="capitalize-input"
          />
        </div>

        <div className="form-group">
          <label data-required>Last Name</label>
          <input
            type="text"
            name="last_name"
            value={formData.last_name}
            onChange={handleChange}
            placeholder="Enter last name"
            className="capitalize-input"
            required
          />
        </div>
      </div>

      <div className="personal-details-grid">
        <div className="form-group">
          <label data-required>Date of Birth</label>
          <input
            type="date"
            name="dob"
            value={formData.dob}
            onChange={handleChange}
            required
          />
        </div>

        

        <div className="form-group">
          <label data-required>Mobile Number</label>
          <input
            type="text"
            name="mobile_number"
            value={formData.mobile_number}
            onChange={handleChange}
            placeholder="10-digit mobile number"
            maxLength="10"
            required
          />
        </div>

        <div className="form-group">
          <label data-required>Email</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Enter email address"
            required
          />
        </div>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="form-step">
      <h3>Address Details</h3>
      <div className="address-fields">
        <div className="form-group">
          <label data-required>Address Line 1</label>
          <input
            type="text"
            name="address_1"
            value={formData.address_1}
            onChange={handleChange}
            placeholder="House/Flat No., Building Name, Street"
            required
          />
        </div>
        
        <div className="form-group">
          <label data-required>Address Line 2</label>
          <input
            type="text"
            name="address_2"
            value={formData.address_2}
            onChange={handleChange}
            placeholder="Area, Colony"
            
          />
        </div>

       

        <div className="address-grid">
          <div className="form-group">
            <label data-required>City</label>
            <input
              type="text"
              name="city"
              value={formData.city}
              onChange={handleChange}
              placeholder="Enter city"
              required
            />
          </div>

          <div className="form-group">
            <label data-required>State</label>
            <input
              type="text"
              name="state"
              value={formData.state}
              onChange={handleChange}
              placeholder="Enter state"
              required
            />
          </div>

          <div className="form-group">
            <label data-required>Pincode</label>
            <input
              type="text"
              name="pincode"
              value={formData.pincode}
              onChange={handleChange}
              placeholder="6-digit pincode"
              maxLength="6"
              required
            />
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="registration-card">
      <div className="top-nav">
        <div className="nav-links">
          {/* Removed FAQ and Helpline buttons */}
        </div>
      </div>

      <h2>Registration</h2>
      
      {submitStatus.message && (
        <div className={`status-message ${submitStatus.type}`}>
          {submitStatus.message}
        </div>
      )}
      
      <div className="form-content mobile-responsive">
        {/* Personal Details Section */}
        <div className="form-section mobile-section">
          {renderStep1()}
        </div>

        {/* Address Section */}
        <div className="form-section mobile-section">
          {renderStep2()}
        </div>

        {/* Education & Skills Section */}
        <div className="form-section mobile-section">
          <h3>Education & Skills</h3>
          <div className="input-row">
            <div className="input-field">
              <label>Education <span className="required">*</span></label>
              <select 
                name="education" 
                value={formData.education} 
                onChange={handleChange}
                className={errors.education ? "error-input" : ""}
                disabled={isSubmitting}
              >
                <option value="">Select Education</option>
                <option value="Masters">Masters</option>
                <option value="Bachelors">Bachelors</option>
                <option value="Others">Others</option>
              </select>
              {errors.education && <div className="error-message">{errors.education}</div>}
            </div>

            <div className="input-field">
              <label>Experience <span className="required">*</span></label>
              <select 
                name="experience" 
                value={formData.experience} 
                onChange={handleChange}
                className={errors.experience ? "error-input" : ""}
                disabled={isSubmitting}
              >
                <option value="">Select Experience</option>
                <option value="1-2 Years">1-2 Years</option>
                <option value="3-4 Years">3-4 Years</option>
                <option value="5-6 Years">5-6 Years</option>
                <option value="8+ Years">8+ Years</option>
              </select>
              {errors.experience && <div className="error-message">{errors.experience}</div>}
            </div>
          </div>

          {formData.education === "Others" && (
            <div className="input-field">
              <label>Specify Education <span className="required">*</span></label>
              <input 
                type="text" 
                name="otherEducation" 
                value={formData.otherEducation} 
                placeholder="Specify your education"
                onChange={handleChange}
                className={errors.otherEducation ? "error-input" : ""}
                disabled={isSubmitting}
              />
              {errors.otherEducation && <div className="error-message">{errors.otherEducation}</div>}
            </div>
          )}

          <div className="input-field">
            <label>Skills <span className="required">*</span></label>
            <Select
              isMulti
              name="skills"
              options={skillOptions}
              className={`basic-multi-select ${errors.skills ? "error-input" : ""}`}
              classNamePrefix="select"
              value={skillOptions.filter(option => formData.skills.includes(option.value))}
              onChange={(selectedOptions) => {
                const selectedSkills = selectedOptions ? selectedOptions.map(option => option.value) : [];
                setFormData({ ...formData, skills: selectedSkills });
              }}
              placeholder="Select skills (minimum one required)"
              isDisabled={isSubmitting}
            />
            {errors.skills && <div className="error-message">{errors.skills}</div>}
          </div>
        </div>

        <button 
          className={`submit-btn btn-ripple mobile-button ${isSubmitting ? 'loading' : ''}`}
          onClick={handleSubmit}
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <>
              <span className="spinner"></span>
              Registering...
            </>
          ) : (
            <>
              Register <span className="btn-icon">✓</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default Registration;
