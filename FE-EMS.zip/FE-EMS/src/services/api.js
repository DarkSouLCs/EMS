import axios from 'axios';

// Create an axios instance with default config
const api = axios.create({
  baseURL: 'http://localhost:3000/api/v1',
  headers: {
    'Content-Type': 'application/json'
  },
  timeout: 10000 // 10 seconds timeout
});

// Add a request interceptor to add auth token to requests
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add a response interceptor to handle common errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // Handle 401 Unauthorized errors (token expired)
    if (error.response && error.response.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Authentication API endpoints
export const authAPI = {
  // Register a new user
  register: async (userData) => {
    try {
      const response = await api.post('/user_registration', userData);
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Registration failed');
      } else if (error.request) {
        throw new Error('Network error. Please check your connection.');
      } else {
        throw new Error('An unexpected error occurred');
      }
    }
  },

  // Login user
  login: async (credentials) => {
    try {
      const response = await api.post('/login', credentials);
      if (response.data.token) {
        localStorage.setItem('token', response.data.token);
      }
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Login failed');
      } else if (error.request) {
        throw new Error('Network error. Please check your connection.');
      } else {
        throw new Error('An unexpected error occurred');
      }
    }
  },

  // Logout user
  logout: () => {
    localStorage.removeItem('token');
    window.location.href = '/login';
  },

  // Check if user is authenticated
  isAuthenticated: () => {
    return !!localStorage.getItem('token');
  }
};

// Employee API endpoints
export const employeeAPI = {
  // Get all employees
  getAllEmployees: async () => {
    try {
      const response = await api.get('/employees');
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to fetch employees');
    }
  },

  // Get employee by ID
  getEmployeeById: async (id) => {
    try {
      const response = await api.get(`/employees/${id}`);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to fetch employee');
    }
  },

  // Create new employee
  createEmployee: async (employeeData) => {
    try {
      // Ensure the data is properly formatted
      const formattedData = {
        first_name: employeeData.first_name,
        middle_name: employeeData.middle_name || '',
        last_name: employeeData.last_name,
        mobile_number: employeeData.mobile_number,
        address_1: employeeData.address_1,
        address_2: employeeData.address_2 || '',
        city: employeeData.city,
        state: employeeData.state,
        pincode: employeeData.pincode,
        experience: employeeData.experience,
        education: employeeData.education,
        skills: employeeData.skills.join(','),
        email: employeeData.email
      };
      
      const response = await api.post('/employee', formattedData);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to create employee');
    }
  },

  // Update employee
  updateEmployee: async (id, employeeData) => {
    try {
      const response = await api.put(`/employees/${id}`, employeeData);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to update employee');
    }
  },

  // Delete employee
  deleteEmployee: async (id) => {
    try {
      const response = await api.delete(`/employees/${id}`);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to delete employee');
    }
  },

  // Search employee by registration number
  search: async (registrationNumber) => {
    try {
      const response = await api.post('/search', { registration_number: registrationNumber });
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to search employee');
    }
  },

  // Register new employee with auto-generated registration number
  register: async (employeeData) => {
    try {
      const response = await api.post('/register', employeeData);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to register employee');
    }
  },

  // Save registration form data by email
  saveRegistrationData: async (formData) => {
    try {
      const response = await api.post('/registration/save', {
        email: formData.email,
        data: formData
      });
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to save registration data');
    }
  },

  // Get saved registration form data by email
  getRegistrationData: async (email) => {
    try {
      const response = await api.get(`/registration/data/${email}`);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to get registration data');
    }
  },

  // Update registration form data by email
  updateRegistrationData: async (formData) => {
    try {
      const response = await api.put(`/registration/update/${formData.email}`, formData);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to update registration data');
    }
  },

  // Get all registrations for an email
  getRegistrationsByEmail: async (email) => {
    try {
      const response = await api.get(`/registration/history/${email}`);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to get registration history');
    }
  }
};

// Skills API endpoints
export const skillsAPI = {
  // Get all skills
  getAllSkills: async () => {
    try {
      const response = await api.get('/skills');
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to fetch skills');
    }
  },

  // Add skill to employee
  addSkillToEmployee: async (employeeId, skillData) => {
    try {
      const response = await api.post(`/employees/${employeeId}/skills`, skillData);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to add skill');
    }
  },

  // Remove skill from employee
  removeSkillFromEmployee: async (employeeId, skillId) => {
    try {
      const response = await api.delete(`/employees/${employeeId}/skills/${skillId}`);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to remove skill');
    }
  }
};

export default api; 