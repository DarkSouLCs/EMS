import React from 'react';
import './FAQ.css';

const FAQ = () => {
  return (
    <div className="faq-container">
      <h1>Frequently Asked Questions</h1>
      
      <div className="faq-list">
        <div className="faq-item">
          <h3>How do I register as a new employee?</h3>
          <p>Fill in all required fields marked with * in the registration form. Make sure to:</p>
          <ul>
            <li>Provide valid contact information</li>
            <li>Enter your complete address details</li>
            <li>Select your education qualification</li>
            <li>Choose relevant skills from the dropdown</li>
          </ul>
        </div>

        <div className="faq-item">
          <h3>What format should the mobile number be in?</h3>
          <p>Mobile number should be 10 digits starting with 6-9. For example: 9876543210</p>
        </div>

        <div className="faq-item">
          <h3>How can I search for an employee?</h3>
          <p>Use the search page and enter the 7-digit registration number provided during registration.</p>
        </div>

        <div className="faq-item">
          <h3>What skills can I select?</h3>
          <p>You can select multiple skills from the predefined list including JavaScript, Python, Java, React, etc. At least one skill is mandatory.</p>
        </div>

        <div className="faq-item">
          <h3>How do I update my information?</h3>
          <p>Contact our support team at support@company.com or call our helpline at 1800-XXX-XXXX for any updates.</p>
        </div>
      </div>

      <div className="quick-contact">
        <p>Still have questions? Contact us:</p>
        <div className="contact-info">
          <p>📞 1800-XXX-XXXX</p>
          <p>✉️ support@company.com</p>
        </div>
      </div>
    </div>
  );
};

export default FAQ; 