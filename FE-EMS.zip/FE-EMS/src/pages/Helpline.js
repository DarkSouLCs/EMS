import React from 'react';
import './Helpline.css';

const Helpline = () => {
  // Prefilled contact details
  const contactInfo = {
    phone: "1800-123-4567",
    email: "support@company.com",
    whatsapp: "9876543210"
  };

  // Direct action handlers
  const handleCall = () => {
    window.location.href = `tel:${contactInfo.phone}`;
  };

  const handleEmail = () => {
    window.location.href = `mailto:${contactInfo.email}?subject=Support Request&body=Hello, I need assistance with...`;
  };

  const handleWhatsApp = () => {
    window.location.href = `https://wa.me/${contactInfo.whatsapp}?text=Hello, I need assistance with...`;
  };

  return (
    <div className="helpline-container">
      <h1>Contact Support</h1>
      
      <div className="contact-cards">
        <div className="contact-card" onClick={handleCall}>
          <div className="icon">📞</div>
          <h2>Call Support</h2>
          <p className="contact-detail">{contactInfo.phone}</p>
          <p className="timing">Monday to Friday: 9 AM - 6 PM</p>
          <button className="contact-btn">Call Now</button>
        </div>

        <div className="contact-card" onClick={handleEmail}>
          <div className="icon">✉️</div>
          <h2>Email Support</h2>
          <p className="contact-detail">{contactInfo.email}</p>
          <p className="timing">24/7 Email Support</p>
          <button className="contact-btn">Send Email</button>
        </div>

        <div className="contact-card" onClick={handleWhatsApp}>
          <div className="icon">💬</div>
          <h2>WhatsApp Support</h2>
          <p className="contact-detail">{contactInfo.whatsapp}</p>
          <p className="timing">Available 24/7</p>
          <button className="contact-btn">Chat Now</button>
        </div>
      </div>

      <div className="support-hours">
        <h2>Support Hours</h2>
        <div className="hours-grid">
          <div className="hour-item">
            <h3>Phone Support</h3>
            <p>Monday - Friday: 9 AM - 6 PM</p>
            <p>Saturday: 9 AM - 1 PM</p>
            <p>Sunday: Closed</p>
          </div>
          <div className="hour-item">
            <h3>Email & WhatsApp</h3>
            <p>24/7 Available</p>
            <p>Response Time: Within 2 hours</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Helpline; 