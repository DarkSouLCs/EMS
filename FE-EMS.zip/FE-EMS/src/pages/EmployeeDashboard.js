import React from 'react';
import { Link } from 'react-router-dom';
import './EmployeeDashboard.css';

const EmployeeDashboard = () => {
  return (
    <div className="dashboard-container">
      <nav className="main-nav">
        <div className="nav-logo">Employee Portal</div>
        <div className="nav-links">
          <Link to="/" className="nav-link">Dashboard</Link>
          <Link to="/faq" className="nav-link">FAQ</Link>
          <Link to="/helpline" className="nav-link">Helpline</Link>
        </div>
      </nav>

      <div className="dashboard-content">
        <h1>Employee Dashboard</h1>
        {/* Your existing search page content */}
      </div>
    </div>
  );
};

export default EmployeeDashboard; 