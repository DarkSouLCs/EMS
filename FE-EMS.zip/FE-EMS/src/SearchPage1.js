import React, { useState, useEffect } from "react";
import "./SearchPage1.css"; // Import styles
import { useNavigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import { employeeAPI } from './services/api';

const SearchPage1 = () => {
  const [registrationNumber, setSearchRegNumber] = useState("");
  const [employeeData, setEmployeeData] = useState(null);
  const [error, setError] = useState("");
  const [showFAQ, setShowFAQ] = useState(false);
  const [showHelpline, setShowHelpline] = useState(false);
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
    }
  }, [isAuthenticated, navigate]);

  let response;
  // Fetch employee details from backend
  const handleSearch = async () => {
    if (!registrationNumber.trim()) {
      setError("Please enter a registration number.");
      setEmployeeData(null);
      return;
    }

    try {
      setError(""); // Reset any previous errors
      const response = await employeeAPI.search(registrationNumber);

      // Check if the response contains data
      if (response && response.data) {
        setEmployeeData(response.data);
        setError(""); // Clear any previous errors
      } else {
        setEmployeeData(null);
        setError("No records found for this registration number.");
      }
    } catch (err) {
      console.error("Error fetching data:", err);
      setEmployeeData(null);
      setError(err.message || "No records found for this registration number.");
    }
  };

  // Add this function to handle input validation
  const handleSearchInput = (e) => {
    const value = e.target.value;
    // Only allow numbers
    if (value === '' || /^[0-9]+$/.test(value)) {
      setSearchRegNumber(value);
    }
  };

  return (
    <div className="common-container">
      <div className="top-right-links">
        {/* Removed FAQ and Helpline buttons */}
      </div>

      {showFAQ && (
        <div className="modal">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Frequently Asked Questions</h3>
              <button className="close-btn" onClick={() => setShowFAQ(false)}>×</button>
            </div>
            <div className="faq-list">
              <div className="faq-item">
                <h4>How do I search for a registration?</h4>
                <p>Enter the registration number in the search box and click the search button.</p>
              </div>
              <div className="faq-item">
                <h4>What information will be displayed?</h4>
                <p>The search results will show personal details, contact information, and skills of the registered person.</p>
              </div>
              <div className="faq-item">
                <h4>Can't find a registration?</h4>
                <p>Make sure you've entered the correct registration number. If you still can't find it, contact our helpline.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {showHelpline && (
        <div className="modal">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Helpline Information</h3>
              <button className="close-btn" onClick={() => setShowHelpline(false)}>×</button>
            </div>
            <div className="helpline-info">
              <div className="contact-item">
                <h4>Search Support</h4>
                <p>📞 1800-123-4567</p>
                <p>📧 search@example.com</p>
                <p className="timing">Available: Mon-Fri, 9 AM - 6 PM</p>
              </div>
              <div className="contact-item">
                <h4>Technical Support</h4>
                <p>📞 1800-987-6543</p>
                <p>📧 tech@example.com</p>
                <p className="timing">Available: Mon-Sat, 10 AM - 5 PM</p>
              </div>
            </div>
          </div>
        </div>
      )}

      <h2>Search Registration</h2>

      {/* Registration Number Search Field */}
      <div className="search-field">
        <div className="input-group">
          <input
            type="text"
            placeholder="Enter Registration Number"
            value={registrationNumber}
            onChange={handleSearchInput}
            onKeyPress={(e) => {
              // Prevent non-numeric key presses
              if (!/[0-9]/.test(e.key)) {
                e.preventDefault();
              }
            }}
            maxLength={10} // Optional: set a maximum length
            className={error ? "error-input" : ""}
          />
          <button onClick={handleSearch}>Search</button>
        </div>
      </div>

      {error && <div className="error-message">{error}</div>}

      {!error && !employeeData && (
        <div className="no-records">
          <div className="no-records-icon">🔍</div>
          <p>Enter a registration number to search for records</p>
        </div>
      )}

      {employeeData && (
        <div className="table-container">
          <table className="search-table">
            <thead>
              <tr>
                <th>Reg. No</th>
                <th>First Name</th>
                <th>Middle Name</th>
                <th>Last Name</th>
                <th>Phone</th>
                <th>Address 1</th>
                <th>Address 2</th>
                <th>City</th>
                <th>Pincode</th>
                <th>Education</th>
                <th>Experience</th>
                <th>Skills</th>
                <th>Email</th>
              </tr>
            </thead>
            <tbody>
              {Array.isArray(employeeData) ? (
                // Handle array of results (for skills search)
                employeeData.map((employee, index) => (
                  <tr key={employee.registration_number || index}>
                    <td>{employee.registration_number}</td>
                    <td>{employee.first_name}</td>
                    <td>{employee.middle_name || '-'}</td>
                    <td>{employee.last_name}</td>
                    <td>{employee.mobile_number}</td>
                    <td>{employee.address_1}</td>
                    <td>{employee.address_2 || '-'}</td>
                    <td>{employee.city}</td>
                    <td>{employee.pincode}</td>
                    <td>{employee.education}</td>
                    <td>{employee.experience}</td>
                    <td>{employee.skills}</td>
                    <td>{employee.email}</td>
                  </tr>
                ))
              ) : (
                // Handle single result
                <tr>
                  <td>{employeeData.registration_number}</td>
                  <td>{employeeData.first_name}</td>
                  <td>{employeeData.middle_name || '-'}</td>
                  <td>{employeeData.last_name}</td>
                  <td>{employeeData.mobile_number}</td>
                  <td>{employeeData.address_1}</td>
                  <td>{employeeData.address_2 || '-'}</td>
                  <td>{employeeData.city}</td>
                  <td>{employeeData.pincode}</td>
                  <td>{employeeData.education}</td>
                  <td>{employeeData.experience}</td>
                  <td>{employeeData.skills}</td>
                  <td>{employeeData.email}</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default SearchPage1;
 
 