router.post('/search-by-skills', async (req, res) => {
  try {
    const { skills } = req.body;

    // Validate input
    if (!skills || typeof skills !== 'string') {
      return res.status(400).json({
        success: false,
        message: 'Please provide skills to search'
      });
    }

    // Convert skills string to array and clean it
    const skillsArray = skills
      .split(',')
      .map(skill => skill.trim().toLowerCase())
      .filter(skill => skill.length > 0);

    // Create search query using regex for partial matching
    const query = {
      skills: {
        $regex: skillsArray.join('|'),
        $options: 'i'
      }
    };

    const employees = await Employee.find(query)
      .sort({ registration_number: 1 });

    if (!employees || employees.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No employees found with the specified skills'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Employees found successfully',
      data: employees
    });

  } catch (error) {
    console.error('Search by skills error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error.message
    });
  }
}); 